========================================================================
TermFX: Starfield — a free teaser
========================================================================

Theme: space
Summary: The warp-speed starfield, free: a taste of the collection.

REQUIREMENTS:
- Python 3.9 or higher (standard library only - zero dependencies to install!)
- Any modern terminal emulator (supporting ANSI colors / 256 colors / truecolor)
- Works on Linux, macOS, and Windows (WSL, Windows Terminal, PowerShell)

HOW TO RUN:
1. Open your terminal.
2. Run with Python:
     python3 stars.py

CONTROLS:
- Ctrl+C or 'q' to exit.
- Terminal automatically restores cleanly upon exit.
- Resizes dynamically when you adjust your terminal window.

ARTISTIC BACKGROUND:
A high-speed particle simulation testing terminal throughput with 3D projection.

LICENSE & USAGE:
Please see LICENSE.md included in this package.
Original work by subtiliorars / OmniTender Systems.
Thank you for supporting independent digital craft!
========================================================================
